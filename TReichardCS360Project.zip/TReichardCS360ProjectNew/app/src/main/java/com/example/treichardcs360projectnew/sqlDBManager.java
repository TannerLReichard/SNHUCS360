package com.example.treichardcs360projectnew;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;

import java.sql.SQLDataException;

public class sqlDBManager {

    private sqlDBHelper dbHelper;
    private Context context;
    private SQLiteDatabase database;

    public sqlDBManager(Context ctx){
        context = ctx;
    }

    //opens the database for use
    public sqlDBManager open() throws SQLDataException {
        dbHelper = new sqlDBHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    //closes db
    public void close(){
        dbHelper.close();
    }

    //takes in params to insert username and password combo into the table for signup
    public void insert (String username, String password) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(sqlDBHelper.COL_USERNAME, username);
        contentValues.put(sqlDBHelper.COL_PASSWORD, password);
        database.insert(sqlDBHelper.TABLE, null, contentValues);

    }

    //select statement to read through existing records
    public Cursor fetch(){
        String [] columns = new String[] {sqlDBHelper.COL_ID, sqlDBHelper.COL_USERNAME, sqlDBHelper.COL_PASSWORD };
        Cursor cursor = database.query(sqlDBHelper.TABLE, columns, null, null, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }

    //update function to change passwords.
    public int update(long _id, String username, String password) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(sqlDBHelper.COL_USERNAME, username);
        contentValues.put(sqlDBHelper.COL_PASSWORD, password);
        int ret = database.update(sqlDBHelper.TABLE, contentValues, sqlDBHelper.COL_ID + "=" + _id, null);
        return ret;
    }

}
