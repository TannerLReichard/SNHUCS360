package com.example.treichardcs360projectnew;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import androidx.appcompat.app.AppCompatActivity;

public class logIn extends AppCompatActivity {

    EditText editUser;
    EditText editPass;
    sqlDBManager dbManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log_in);

        editUser = (EditText) findViewById(R.id.editUser);
        editPass = (EditText) findViewById(R.id.editPass);

        dbManager = new sqlDBManager(this);
        try{
            dbManager.open();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void btnSignUpPressed(View v){
        dbManager.insert(editUser.getText().toString(),editPass.getText().toString());
        //Intent intent = new Intent(login.this, nextActivity.class);
        //startActivity(intent);
    }

    public void btnLogInPressed(View v){
        Cursor cursor = dbManager.fetch();

        if (cursor.moveToFirst()) {
            do {
                String ID = cursor.getString(cursor.getColumnIndex(sqlDBHelper.COL_ID));
                String username = cursor.getString(cursor.getColumnIndex(sqlDBHelper.COL_USERNAME));
                String password = cursor.getString(cursor.getColumnIndex(sqlDBHelper.COL_PASSWORD));
                Log.i("DATABASE_TAG", "User ID: " + ID + " Username: " + username + "password : " + password);
            } while (cursor.moveToNext());
        }
    }



}
