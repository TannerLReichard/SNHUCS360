package com.example.treichardcs360projectnew;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;


public class sqlDBHelper extends SQLiteOpenHelper {

    //table name and version
    static final String DATABASE_NAME = "accounts.db";
    static final int VERSION = 1;

    //columns for each field in account database
    static final String TABLE = "accounts";
    static final String COL_ID = "_id";
    static final String COL_USERNAME = "_username";
    static final String COL_PASSWORD = "_password";


    //constructor
    public sqlDBHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //on create to create the initial database
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE + " (" +
                COL_ID + " integer primary key autoincrement, " +
                COL_USERNAME + " text, " +
                COL_PASSWORD + " text)");
    }

    //update function to delete and recreate the db in case changes are made
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("drop table if exists " + TABLE);
            onCreate(db);
    }

}
