package com.example.treichardcs360projectnew;

import android.hardware.SensorEventListener;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextWatcher;
import android.widget.Button;
import android.hardware.SensorManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

     EditText nameText;
     TextView textGreeting;
     Button buttonSayHello;
     String txt;
     SensorManager mSensorManager;
     Sensor lightSensor;
    private static final String TAG = "MyActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameText = (EditText) findViewById(R.id.nameText);
        textGreeting = (TextView) findViewById(R.id.textGreeting);
        buttonSayHello = (Button) findViewById(R.id.buttonSayHello);

        txt = nameText.getText().toString();

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        lightSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                txt = nameText.getText().toString();
                if (!txt.matches("")){
                    buttonSayHello.setEnabled(true);
               } else {
                    buttonSayHello.setEnabled(false);
                }

            }
        });
    }

    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, lightSensor,
                SensorManager.SENSOR_DELAY_NORMAL);
    }


    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_LIGHT) {
            float light = sensorEvent.values[0];
            textGreeting.setText("light value: " + light);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    public void SayHello(View view){

    textGreeting.setText("Hello " + txt);

        //if (txt.matches("") != true){
          //  textGreeting.setText("Hello " + txt);
          //  view.setEnabled(false);
       // }

}



}